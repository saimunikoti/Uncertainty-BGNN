"""Namespace for internal apis."""
